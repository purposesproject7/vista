// This file is deprecated and mock data has been removed.
// All data should be fetched from the backend API.
export default {};
